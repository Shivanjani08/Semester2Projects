<!DOCTYPE html>
<html>
<head>
<title>Final Project Info 5737</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Roboto", sans-serif}
  img {
  display: block;
  margin-left: auto;
  margin-right: auto;
     }
</style>
</head>
<body class="w3-light-grey">
 <div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" ">
   <a href="index.php" class="fa fa-home fa-lg w3-bar-item w3-button"> Shivanjani Acholu CV</a>
    <div class="w3-right w3-hide-small">
      <a href="regAcholu.php" class="fa fa-address-card-o fa-lg w3-bar-item w3-button"> Registration Form</a> 
      <a href="contactUsAcholu.php" class="fa fa-phone fa-lg w3-bar-item w3-button"> Contact Us</a>
      <a href="courseReflectAcholu.php" class="fa fa-book fa-lg w3-bar-item w3-button"> Course Reflection</a>
    </div>
  </div>
</div>
<!-- w3-content defines a container for fixed size centered content, 
and is wrapped around the whole page content, except for the footer in this example -->
<div class="w3-content" style="max-width:1400px">

<!-- Header -->
<header class="w3-container w3-center w3-padding-64"> 
  <h1><b><u>Course Reflection</u></b></h1>
  <p><h4>INFO 5737 Information Security and Cybersecurity </h4></p>
</header>

<!-- Grid -->
<div class="w3-row">

<div class="w3-col l8 s12">
  <div class="w3-card-4 w3-margin w3-white">
    <img src="Shivanjani.jpg" alt="pic" style="height:325px;width:250px" >
    <div class="w3-container w3-center">
      <h3><b>Lessons from this course</b></h3>
    </div>

    <div class="w3-container">
      <p>Understanding the diverse range of cyber threats and attacks that exist in the digital realm, including malware, phishing, ransomware, and more.<br> 
        <b>1) Risk management </b>- Techniques for assessing, analyzing, and managing risks associated with information security, including risk identification, mitigation, and response strategies.</p>
      <p><b>2) Network security </b> - Explores the physical aspects of information security, such as securing physical infrastructure, data centers, hardware, and the importance of physical access controls. </p>
      <p><b>3) Implementing Information Security </b> -Practical aspects of deploying security measures within an organization. It may include implementation strategies, configuration, and integration of security technologies..</p>
      <p><b>4) Information Security Maintenance </b> -Focuses on ongoing security management, including monitoring, updates, incident response, and the importance of continuous improvement in information security practices. </p>
      <p><b>5) Planning for Security </b> - Focuses on strategic planning methodologies for implementing comprehensive security frameworks aligned with organizational objectives. This might involve risk assessment, policy development, and resource allocation for security initiatives. </p>
      <p><b>6) Legal, Ethical, and Professional Issues in Information Security </b> - Addresses the legal frameworks, ethical considerations, and professional responsibilities related to information security. This section might delve into compliance requirements, privacy laws, and ethical decision-making in safeguarding information.</p>
      <div class="w3-row">
        <div class="w3-col m8 s12">

        </div>
        <div class="w3-col m4 w3-hide-small">

        </div>
      </div>
    </div>
  </div>
  <hr>
</div>

<!-- Introduction menu -->
<div class="w3-col l4">
  <!-- About Card -->
  <div class="w3-card w3-margin w3-margin-top">
    <div class="w3-container w3-white">
      <h4><b>Future Knowing after this Course
</b></h4>
      <p> <b>Career Advancement: </b>Acquire a valuable skill set highly sought after in various industries, providing opportunities for career growth and advancement in cybersecurity-focused roles.</p>
      <p> <b>Informed Decision-Making: </b>Enhance decision-making capabilities, considering technological advancements, risk analysis, ethical considerations, and legal implications.</p>
    </div>
  </div><hr>

  <!-- Posts -->
  <div class="w3-card w3-margin">
    <div class="w3-container w3-padding">
      <h4>My Favourite Topics</h4>
    </div>
    <ul class="w3-ul w3-hoverable w3-white">
      <li class="w3-padding-16">
        <span class="w3-large">Network security </span><br>
      </li>
      <li class="w3-padding-16">
        <span class="w3-large">Risk management</span><br>
      </li> 
      <li class="w3-padding-16">
        <span class="w3-large">Implementing Information Security</span><br>
      </li>   
      <li class="w3-padding-16 w3-hide-medium w3-hide-small">
        <span class="w3-large">Planning for Security</span><br>
      </li>  
      <li class="w3-padding-16">
        <span class="w3-large">Legal, Ethical, and Professional Issues in Information Security</span><br>
      </li> 
    </ul>
  </div>
  <hr> 

<!-- END Introduction Menu -->
</div>

<!-- END GRID -->
</div><br>

<!-- END w3-content -->
</div>
</body>
</html>
