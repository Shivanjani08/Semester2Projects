<!DOCTYPE html>
<html>
<head>
<title> Final Project Info 5737</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
</style>
</head>
<body class="w3-light-grey">

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" ">
   <a href="index.php" class="fa fa-home fa-lg w3-bar-item w3-button"> Shivanjani Acholu CV</a>
    <div class="w3-right w3-hide-small">
      <a href="regAcholu.php" class="fa fa-address-card-o fa-lg w3-bar-item w3-button"> Registration Form</a> 
      <a href="contactUsAcholu.php" class="fa fa-phone fa-lg w3-bar-item w3-button"> Contact Us</a>
      <a href="courseReflectAcholu.php" class="fa fa-book fa-lg w3-bar-item w3-button"> Course Reflection</a>
    </div>
  </div>
</div>
<!-- Page Container -->
<div class="w3-content w3-margin-top w3-padding-48" style="max-width:1400px;">

  <!-- The Grid -->
  <div class="w3-row-padding">

    <!-- Left Column -->
    <div class="w3-third">

      <div class="w3-white w3-text-grey w3-card-4">
        <div class="w3-display-container">
          <img src="Shivanjani.jpg" style="width:100%" alt="myPic">
         <div class="w3-display-bottomleft w3-container w3-text-white">
            <h2>Shivanjani Acholu</h2>
          </div>
        </div>
        <div class="w3-container">
          <p><i class="fa fa-briefcase fa-fw w3-margin-right w3-large w3-text-blue"></i>Data Scientist</p>
          <p><i class="fa fa-home fa-fw w3-margin-right w3-large w3-text-blue"></i>Denton, Texas</p>
          <p><i class="fa fa-envelope fa-fw w3-margin-right w3-large w3-text-blue"></i>shivanjanireddy08@gmail.com</p>
          <p><i class="fa fa-phone fa-fw w3-margin-right w3-large w3-text-blue"></i>9402184352</p>
          <hr>
           <div class="w3-twothird">  


          <p class="w3-large"><b><i class="fa fa-asterisk fa-fw w3-margin-right w3-text-blue"></i>Skills</b></p>
          <p>HTML,Angular,MySQL</p>
          <div class="w3-light-grey w3-round-xlarge w3-small">
            <div class="w3-container w3-center w3-round-xlarge w3-blue" style="width:80%">
              <div class="w3-center w3-text-white">90%</div>
            </div>
          </div>
        <!--  <p>Database SQL</p>
          <div class="w3-light-grey w3-round-xlarge w3-small">
            <div class="w3-container w3-center w3-round-xlarge w3-blue" style="width:90%">90%</div>
          </div>-->
          <p>Python,java,C,C++</p>
          <div class="w3-light-grey w3-round-xlarge w3-small">
            <div class="w3-container w3-center w3-round-xlarge w3-blue" style="width:95%">95%</div>
          </div>
          <br>

          <p class="w3-large w3-text-theme"><b><i class="fa fa-globe fa-fw w3-margin-right w3-text-blue"></i>Languages</b></p>
          <p>English</p>
          <div class="w3-light-grey w3-round-xlarge">
            <div class="w3-round-xlarge w3-blue" style="height:20px;width:100%"></div>
          </div>
          <br>
        </div>
      </div><br>

    <!-- End Left Column -->
    </div>

    <!-- Right Column -->

      </div>
       <div class="w3-twothird">

      <div class="w3-container w3-card w3-white w3-margin-bottom">
        <h2 class="w3-text-grey w3-padding-16"><i class="fa fa-certificate fa-fw w3-margin-right w3-xxlarge w3-text-blue"></i>Summary</h2>
        <div class="w3-container">

          <p>Diligent and reliable professional adept at effectively overseeing diverse tasks while maintaining an upbeat demeanor. Proven track record in prioritizing multiple responsibilities with precision and a proactive approach. Eager to assume additional duties in pursuit of collective team objectives.</p>
          <hr>
        </div>
        <div class="w3-container w3-card w3-white w3-margin-bottom">
        <h2 class="w3-text-grey w3-padding-16"><i class="fa fa-suitcase fa-fw w3-margin-right w3-xxlarge w3-text-blue"></i>Work Experience</h2>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>Accenture India Pvt.Ltd</b></h5>
          <h6 class="w3-text-blue"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Aug 2021- Nov 2022 </h6>
          <p>Worked with an Agro-science based client called Corteva, which manages the loans of the customers for their agricultural purposes. My job is to manage the databases and maintain the servers using SQL and Unit testing.</p>
          <hr>
        </div>

      <div class="w3-container w3-card w3-white">
        <h2 class="w3-text-grey w3-padding-16"><i class="fa fa-certificate fa-fw w3-margin-right w3-xxlarge w3-text-blue"></i>Education</h2>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>University of North Texas</b></h5>
          <h6 class="w3-text-blue"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Jan 2023 - Present</h6>
          <p>Master of Science in Data Science </p>
          <hr>
        </div>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>Sri Venkateswara college of Engineering</b></h5>
          <h6 class="w3-text-blue"><i class="fa fa-calendar fa-fw w3-margin-right"></i>2017 - 2021</h6>
          <p>Bachelor of Engineering in Electronics and communication  Engineering</p>
          <hr>
        </div>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>Narayana Junior College</b></h5>
          <h6 class="w3-text-blue"><i class="fa fa-calendar fa-fw w3-margin-right"></i>2015 - 2017</h6>
          <p>Intermediate</p><br>
        </div>

      </div>

    <!-- End Right Column -->
    </div>

  <!-- End Grid -->
  </div>

  <!-- End Page Container -->
</div>

<footer class="w3-container w3-blue w3-center w3-margin-top">
  <p>Find me on social media.</p>
  <i class="fa fa-facebook-official w3-hover-opacity"></i>
  <i class="fa fa-instagram w3-hover-opacity"></i>
  <i class="fa fa-snapchat w3-hover-opacity"></i>
  <i class="fa fa-twitter w3-hover-opacity"></i>
  <i class="fa fa-linkedin w3-hover-opacity"></i>
  <p>Powered by <a href="" target="_blank">VishnuVardhan</a></p>
</footer>

</body>
</html>

