<!DOCTYPE html>
<html>
<head>
<title> Final Project Info 5737</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
</style>
</head>
<body class="w3-light-grey">

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" ">
    <a href="index.php" class="fa fa-home fa-lg w3-bar-item w3-button"> Shivanjani Acholu CV</a>
    <div class="w3-right w3-hide-small">
      <a href="regAcholu.php" class="fa fa-address-card-o fa-lg w3-bar-item w3-button"> Registration-Form</a> 
      <a href="contactUsAcholu.php" class="fa fa-phone fa-lg w3-bar-item w3-button"> Contact Us</a>
      <a href="courseReflectAcholu.php" class="fa fa-book fa-lg w3-bar-item w3-button"> Course Reflection</a>
    </div>
  </div>
</div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>
<!-- About US Section -->
<div class="w3-container" style="padding:128px 16px" id="mailingList">
  <h3 class="w3-center"> Mailing List Contact Form </h3>
  <p class="w3-center w3-large"><i class="fa fa-phone w3-margin-bottom w3-jumbo w3-center"></i>
  </p>

    <form method="GET" action="submitContact.php">
      <p><input class="w3-input w3-border" type="text" id="firstName" placeholder="First-Name" required name="firstName"></p>
       <p><input class="w3-input w3-border" type="text" id="lastName" placeholder="Last-Name" required name="lastName"></p>
       <p><input class="w3-input w3-border" type="text" id="message" placeholder="Message" required name="message"></p>
        <p><input class="w3-input w3-border" type="email" id="email" placeholder="E-mail" required name="email"></p>
      <p><button class="w3-button w3-black" type="submit">
          <i class="fa fa-envelope"></i> Submit
        </button>
      </p>
    </form>
</div>
</html>