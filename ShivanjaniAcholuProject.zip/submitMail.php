<!DOCTYPE html>
<html>
<head>
<title> Final Project Info 5737 </title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
</style>
</head>
<body class="w3-light-grey">

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" ">
    <a href="index.php" class="fa fa-home fa-lg w3-bar-item w3-button"> Shivanjani Acholu CV</a>
    <div class="w3-right w3-hide-small">
      <a href="regAcholu.php" class="fa fa-address-card-o fa-lg w3-bar-item w3-button"> Registration Form</a> 
      <a href="contactUsAcholu.php" class="fa fa-phone fa-lg w3-bar-item w3-button"> Contact Us</a>
      <a href="courseReflectAcholu.php" class="fa fa-book fa-lg w3-bar-item w3-button"> Course Reflection</a>
    </div>
  </div>
</div>


<div class="container w3-white w3-padding-32">
</div>

<?php
if (!empty($_POST)){
   $firstName = $_POST['firstName'];
   $lastName= $_POST['lastName'];
   $birthday = $_POST['birthday'];
   $email = $_POST['email'];

     echo "<p>&nbsp; &nbsp; First Name : <b>" . $firstName . "</b>.</p>"; 
     echo "<p>&nbsp; &nbsp; Last Name : <b>" . $lastName . "</b>.</p>";       
     echo "<p>&nbsp; &nbsp; Birthday : <b>" . $birthday . "</b>.</p>";       
     echo "<p>&nbsp; &nbsp; E-mail : <b>" . $email . "</b>.</p>";       
}